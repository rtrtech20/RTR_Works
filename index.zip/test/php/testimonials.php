<!--Start Testinomial-->
<section class="dg-testinomial-section pb80 pt80">
      <div class="container">
        <div class="row mt60">
          <div class="col-lg-6">
            <div class="common-heading text-l">
              <h2 class="mb0">What our clients say about our design</h2>
            </div>
            <div class="owl-carousel testimonial-card-b mt60">
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="testimonial-card">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div class="-client-details- mt20">
                  <i class="fas fa-quote-left posiqut"></i>
                  <div class="reviewer-text">
                    <h4>Buck Kinnear</h4>
                    <p>Business Owner, <small>Jaipur</small></p>
                    <div class="star-rate mt10">
                      <ul>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)" class="chked"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                        <li>
                          <a href="javascript:void(0)"
                            ><i class="fas fa-star" aria-hidden="true"></i
                          ></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="clients-creative-pic pl25">
              <div class="owl-dots" id="testimonials-avatar">
                <button class="dot-c1 tcc1 owl-dot active">
                  <img alt="image" src="images/user-thumb/user1.jpg" />
                </button>
                <button class="dot-c1 tcc2 owl-dot">
                  <img alt="image" src="images/user-thumb/user2.jpg" />
                </button>
                <button class="dot-c1 tcc3 owl-dot">
                  <img alt="image" src="images/user-thumb/user3.jpg" />
                </button>
                <button class="dot-c1 tcc4 owl-dot">
                  <img alt="image" src="images/user-thumb/user4.jpg" />
                </button>
                <button class="dot-c1 tcc5 owl-dot">
                  <img alt="image" src="images/user-thumb/user5.jpg" />
                </button>
                <button class="dot-c1 tcc6 owl-dot">
                  <img alt="image" src="images/user-thumb/user1.jpg" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--End Testinomial-->