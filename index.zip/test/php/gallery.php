<!--start photo gallery-->
<div class="photosets- pb80 pt50">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 mt30 h-scl-">
            <div class="img-ca2set h-scl-base">
              <img
                src="images/about/office-1.jpg"
                alt="companyname"
                class="img-fluid"
              />
            </div>
          </div>
          <div class="col-lg-7 mt30 h-scl-">
            <div class="img-ca2set h-scl-base">
              <img
                src="images/about/office-2.jpg"
                alt="companyname"
                class="img-fluid"
              />
            </div>
          </div>
          <div class="col-lg-7 mt30 h-scl-">
            <div class="img-ca2set h-scl-base">
              <img
                src="images/about/office-3.jpg"
                alt="companyname"
                class="img-fluid"
              />
            </div>
          </div>
          <div class="col-lg-5 mt30 h-scl-">
            <div class="img-ca2set h-scl-base">
              <img
                src="images/about/office-4.jpg"
                alt="companyname"
                class="img-fluid"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--End photo gallery-->