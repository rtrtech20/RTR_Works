<!--Start Team-->
<section class="dg-testinomial-section pb80 pt80" id="team">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="common-heading">
              <h2 class="mb20">Our Team</h2>
              <p class="mb30">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum is simply dummy text of the printing and
                typesetting industry.
              </p>
            </div>
          </div>
        </div>
        <div class="single-slide owl-carousel mt60">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-4">
              <div class="image-block upset h-scl-">
                <div class="image-div h-scl-base">
                  <img
                    src="images/team/team-single.jpg"
                    alt="team"
                    class="img-fluid"
                  />
                </div>
              </div>
            </div>
            <div class="col-lg-5 col-md-5">
              <div class="full-image-card mt0">
                <div class="info-text-block">
                  <h3><a href="#">Anna Rexia</a></h3>
                  <p>Company CTO</p>
                  <div class="social-media-profile">
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-facebook"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-instagram"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-linkedin"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-dribbble"></i
                    ></a>
                  </div>
                </div>
                <div class="otherinfo">
                  <p>
                    "Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-4">
              <div class="image-block upset">
                <div class="image-div">
                  <a href="#"
                    ><img
                      src="images/team/team-single.jpg"
                      alt="team"
                      class="img-fluid"
                  /></a>
                </div>
              </div>
            </div>
            <div class="col-lg-5 col-md-5">
              <div class="full-image-card mt0">
                <div class="info-text-block">
                  <h3><a href="#">Anna Rexia</a></h3>
                  <p>Company CTO</p>
                  <div class="social-media-profile">
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-facebook"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-twitter"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-instagram"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-linkedin"></i
                    ></a>
                    <a href="javascript:void(0)" target="blank"
                      ><i class="fab fa-dribbble"></i
                    ></a>
                  </div>
                </div>
                <div class="otherinfo">
                  <p>
                    "Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--End Team-->