<div class="cta-sec-bhv pb80 pt80">
      <div class="container">
        <div class="row justify-content-center text-center">
          <div class="col-lg-7">
            <div class="email-subs">
              <h3>Get New Insights Weekly</h3>
              <p>
                News letter dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt. Enter your email
              </p>
            </div>
          </div>
        </div>
        <div class="row justify-content-center mt40">
          <div class="col-lg-4 v-center">
            <div class="email-subs-form">
              <input type="text" placeholder="Name" name="name" />
            </div>
          </div>
          <div class="col-lg-5 v-center">
            <div class="email-subs-form">
              <div class="form-cta">
                <input type="email" placeholder="Email Address" name="emails" />
                <button
                  type="submit"
                  name="submit"
                  class="lnk btn-main bg-btn7"
                >
                  Subscribe <i class="fas fa-chevron-right fa-icon"></i
                  ><span class="circle"></span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>